import { useEffect, useRef } from "react";
import { Link } from "react-router";
import { useLanguage } from "@/contexts/LanguageContext";
import { Mail, Award, BookOpen } from "lucide-react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";

gsap.registerPlugin(ScrollTrigger);
// eslint-disable-next-line @typescript-eslint/no-explicit-any
const GSAP: any = gsap;

export default function Leadership() {
  const { language, t, dir } = useLanguage();
  const isArabic = language === "ar";
  const sectionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      if (sectionRef.current) {
        GSAP.fromTo(
          sectionRef.current.querySelectorAll(".leader-animate"),
          { opacity: 0, y: 30 },
          {
            opacity: 1,
            y: 0,
            duration: 0.8,
            stagger: 0.15,
            scrollTrigger: {
              trigger: sectionRef.current,
              start: "top 80%",
            },
          }
        );
      }
    });
    return () => ctx.revert();
  }, []);

  const leaders = [
    {
      name: t("leadership.principal.name"),
      role: t("leadership.principal.role"),
      bio: t("leadership.principal.bio"),
      image: "/images/leader-principal.jpg",
      email: "principal@iks.edu.sa",
      qualifications: [
        isArabic ? "دكتوراه في الإدارة التعليمية" : "Ph.D. in Educational Leadership",
        isArabic ? "ماجستير في التعليم" : "Masters in Education",
        isArabic ? "20+ عاماً من الخبرة" : "20+ Years of Experience",
      ],
    },
    {
      name: t("leadership.director.name"),
      role: t("leadership.director.role"),
      bio: t("leadership.director.bio"),
      image: "/images/leader-academic.jpg",
      email: "academic@iks.edu.sa",
      qualifications: [
        isArabic ? "دكتوراه في المناهج والتدريس" : "Ph.D. in Curriculum & Instruction",
        isArabic ? "ماجستير في علم النفس التربوي" : "Masters in Educational Psychology",
        isArabic ? "15+ عاماً من الخبرة" : "15+ Years of Experience",
      ],
    },
  ];

  return (
    <div dir={dir}>
      <section className="relative min-h-[40vh] max-h-[400px] flex items-center justify-center bg-gradient-hero">
        <div className="relative z-10 text-center px-4">
          <h1 className="text-4xl md:text-[56px] font-bold text-white mb-3">
            {t("page.leadership")}
          </h1>
          <div className="flex items-center justify-center gap-2 text-sm text-white/60">
            <Link to="/" className="hover:text-white transition-colors">
              {t("nav.home")}
            </Link>
            <span>/</span>
            <span className="text-white/80">{t("page.leadership")}</span>
          </div>
        </div>
      </section>

      <div ref={sectionRef} className="bg-white section-padding">
        <div className="container-main">
          <div className="text-center mb-12">
            <h2 className="leader-animate text-3xl md:text-[42px] font-bold text-[#1A1A1A] mb-4">
              {t("leadership.title")}
            </h2>
            <p className="leader-animate text-base md:text-lg text-[#7C7C7C] max-w-2xl mx-auto">
              {t("leadership.subtitle")}
            </p>
          </div>

          <div className="space-y-12 max-w-5xl mx-auto">
            {leaders.map((leader, i) => (
              <div
                key={i}
                className={`leader-animate card-shadow bg-white border border-[rgba(11,30,53,0.08)] rounded-lg overflow-hidden ${
                  dir === "rtl" ? "lg:direction-rtl" : ""
                }`}
              >
                <div className="grid lg:grid-cols-3 gap-0">
                  <div
                    className={`lg:col-span-1 ${
                      dir === "rtl" ? "lg:order-2" : ""
                    }`}
                  >
                    <img
                      src={leader.image}
                      alt={leader.name}
                      className="w-full h-full object-cover min-h-[300px] lg:min-h-[400px]"
                    />
                  </div>
                  <div
                    className={`lg:col-span-2 p-8 lg:p-10 ${
                      dir === "rtl" ? "lg:order-1" : ""
                    }`}
                  >
                    <h3 className="text-2xl font-bold text-[#1A1A1A] mb-1">
                      {leader.name}
                    </h3>
                    <p className="text-base text-[#213B6F] font-medium mb-4">
                      {leader.role}
                    </p>
                    <p className="text-base text-[#7C7C7C] leading-relaxed mb-6">
                      {leader.bio}
                    </p>

                    <div className="mb-6">
                      <h4 className="text-sm font-semibold text-[#1A1A1A] mb-3 flex items-center gap-2">
                        <Award size={16} className="text-[#F0B736]" />
                        {isArabic ? "المؤهلات" : "Qualifications"}
                      </h4>
                      <ul className="space-y-2">
                        {leader.qualifications.map((q, j) => (
                          <li
                            key={j}
                            className="flex items-center gap-2 text-sm text-[#7C7C7C]"
                          >
                            <BookOpen size={14} className="text-[#213B6F] shrink-0" />
                            {q}
                          </li>
                        ))}
                      </ul>
                    </div>

                    <a
                      href={`mailto:${leader.email}`}
                      className="inline-flex items-center gap-2 text-[#213B6F] font-medium hover:underline"
                    >
                      <Mail size={16} />
                      {leader.email}
                    </a>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
